for i in range(8):
    numero = int(input("Digite um número: "))

    if numero % 4 == 0:
        print(numero, "é divisível por 4")