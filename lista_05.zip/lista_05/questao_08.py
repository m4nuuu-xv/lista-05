numero = input("Digite um número inteiro: ")
digito = input("Digite um dígito de 0 a 9: ")

contador = 0

for i in numero:
    if i == digito:
        contador += 1

print("O dígito aparece", contador, "vezes")