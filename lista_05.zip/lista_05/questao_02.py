n = int(input("Digite um número inteiro: "))

for i in range(1, 11):
    print(n, "x", i, "=", n * i)