numero = input("Digite um número inteiro positivo: ")

quantidade = 0

for i in numero:
    quantidade += 1

print("Quantidade de dígitos:", quantidade)