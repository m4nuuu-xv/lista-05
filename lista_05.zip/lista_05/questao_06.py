total = 0

for i in range(1, 8):
    consumo = float(input(f"Digite o consumo do produto {i}: "))

    total += consumo

    if i == 1:
        maior_consumo = consumo
        produto_maior = i
    else:
        if consumo > maior_consumo:
            maior_consumo = consumo
            produto_maior = i

print("Consumo total:", total, "kg")
print("Produto que mais consome:", produto_maior)
print("Maior consumo:", maior_consumo, "kg")